# Implied SPX distributions

Risk-neutral and physical probability distributions for the S&P 500,
recovered from SPX option chains.

The pipeline estimates forwards and discount factors from put-call parity,
fits an arbitrage-free call-price curve (Fengler), reads the risk-neutral
density off its second derivative (Breeden-Litzenberger), scores the result
against realised Cboe SET settlement values with CRPS, and asks whether a
one-parameter CRRA pricing kernel moves the densities closer to outcomes.

## Run it without any data

The raw vendor chains are not redistributable. A synthetic generator stands
in for them: chains priced in closed form from a lognormal mixture, with
SPX-like strike ladders, bid-ask spreads, tick rounding and stale quotes,
and outcomes drawn from a CRRA tilt of the true density at a **known**
gamma.

```bash
python -m implied_stock_distributions.demo
```

About a minute. It runs the whole pipeline and prints the sample size, the
scores, the inference and the recovered gamma against the true one, and
writes `figures/synthetic_demo.png`.

To write a synthetic dataset the notebooks can load unchanged:

```bash
python -m implied_stock_distributions.synthetic --out data
```

Then run `notebooks/02_project.ipynb` end to end.

## Three numbers

From the synthetic demonstration, where the true density is known:

| | |
|---|---|
| Mean relative CRPS of the true density (the floor) | **0.0411** |
| Mean relative CRPS of the shape-constrained fit | **0.0412** |
| $L^1$ distance from the true density: constrained vs IV smoothing | **0.095 vs 0.562** |

The first two say the constrained fit gives up almost nothing against a
perfectly specified forecast. The third is the comparison that actually
separates the two methods, and it is only available because the truth is
known.

![Synthetic demonstration](figures/synthetic_demo.png)

## Validating against series the pipeline never sees

Three outputs are checked against published data, none of which enters the
pipeline anywhere:

- the **short rate** backed out of option prices alone, against FRED
  `DGS1MO` / `DGS3MO`;
- the **dividend yield** from the same parity regression, against Shiller's
  realised S&P 500 series;
- the **risk-neutral skewness** of the fitted densities, against Cboe's
  SKEW index — which is computed by a completely different method, so
  agreement tests the recovered *shape* and not only its first moment.

All three are free and need no key. `validation.py` fetches and caches them.

## Layout

```
implied_stock_distributions/
  config.py       paths, sample definition, every hyperparameter
  pricing.py      Black's formula on a forward, and its inversion
  forwards.py     forward and discount factor from put-call parity
  fitting.py      the shape-constrained call-price spline
  smoothing.py    the unconstrained implied-volatility baseline
  selection.py    cross-validated choice of the roughness penalty
  evaluation.py   CRPS, PIT, the CRRA tilt, the gamma interval
  benchmarks.py   lognormal and climatology reference forecasts
  stats.py        Diebold-Mariano, block bootstrap, calibration tests
  validation.py   the external checks above
  synthetic.py    synthetic chains with a known true density
  demo.py         the end-to-end demonstration
  data_access.py  cataloguing and loading processed chains
  plotting.py     the figures
notebooks/
  01_processing.ipynb   raw chains -> monthly Parquet, coverage, SET values
  02_project.ipynb      the analysis and the writeup
tests/
  test_review_fixes.py  33 tests, pytest
```

## Notes on the numbers

Two counting facts govern everything and are worth stating before any
result:

**The effective sample size is the number of distinct expirations**, not the
number of chains. Fourteen analysis years at twelve monthly expirations is
of order 170 outcomes, and all three horizons of one expiration are scored
against the same settlement print. `stats.one_per_expiration` builds the
panel the calibration tests need.

**The Newey-West lag is in rows, not days.** The pooled score table carries
one row per (date, horizon), so a 63-day overlap is 189 rows.
`stats.pooled_hac_lag` does the arithmetic.

`config.ROUGHNESS_PENALTY` is read from
`data/processed/selected_roughness_penalty.json`, written by the
cross-validation cell. `config.ROUGHNESS_PENALTY_IS_DEFAULT` reports whether
that file existed — there is no value to paste anywhere and no placeholder
to forget.

## Tests

```bash
pytest tests/
```

The scoring code is checked against the closed-form Gaussian and lognormal
CRPS, the synthetic mixture is checked against its own Breeden-Litzenberger
density, and each fix from the code review has a test naming the issue it
pins down.
